using UnityEngine;

public abstract class CharacterPart : MonoBehaviour
{
    public abstract void Init();
}

