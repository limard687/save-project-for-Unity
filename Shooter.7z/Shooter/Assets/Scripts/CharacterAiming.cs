using UnityEngine;

public abstract class CharacterAiming : CharacterPart
{

}

