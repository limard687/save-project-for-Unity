using UnityEngine;

public class Enemy : Character
{
    
}