using UnityEngine;
using UnityEngine.Animations.Rigging;

public class Player : Character
{
    
}