using UnityEngine;

public abstract class CharacterMovement : CharacterPart
{

}

