using UnityEngine;

public class GameStateChanger : MonoBehaviour
{
    public GameField GameField;

    public Snake Snake;

    public AppleSpawner AppleSpawner;

    private void Start()
    {
        FirstStartGame();
    }

    private void FirstStartGame()
    {
        GameField.FillCellsPositions();

        StartGame();
    }

    public void StartGame()
    {
        Snake.StartGame();

        AppleSpawner.CreateApple();
    }

    public void EndGame()
    {
        Snake.StopGame();
    }

}
